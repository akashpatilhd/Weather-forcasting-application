# WeatherApp
This is a weather app. It uses openWeather Api to fetch current and predicted weather data of serached cities.
 

<img src="https://user-images.githubusercontent.com/39986507/77046128-6d948300-69e8-11ea-84b5-3774790f935b.png" width="320">  <img src="https://user-images.githubusercontent.com/39986507/78451875-a6e61780-76a5-11ea-9b24-79be1ed38b37.png" width="320">  



<img src="https://user-images.githubusercontent.com/39986507/83872725-2ba9ec00-a750-11ea-8a47-5a32f56eedec.png" width="320">   <img src="https://user-images.githubusercontent.com/39986507/83606871-e5119180-a597-11ea-856d-734343583f30.png" width="320">
